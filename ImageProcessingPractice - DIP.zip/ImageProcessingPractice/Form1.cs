using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WebCamLib;
using AForge.Video;
using AForge.Video.DirectShow;

namespace ImageProcessingPractice
{
    public partial class Form1 : Form
    {
        Bitmap loaded;
        Bitmap processed;
        Bitmap imageB, imageA;
        private Device dev;
        bool isRunning = false;
        private Func<Bitmap, Bitmap> selectedFilter;
        private VideoCaptureDevice videoSource;
        private FilterInfoCollection videoDevices;

        public Form1()
        {
            InitializeComponent();
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image Files|*.bmp;*.jpg;*.jpeg;*.png;*.gif|All Files|*.*";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                loaded = new Bitmap(openFileDialog1.FileName);
                pictureBox1.Image = loaded;
                // The openFileDialog1_FileOk event will be triggered when the user selects a file.
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            loaded = new Bitmap(openFileDialog1.FileName);
            Color pixel;
            processed = new Bitmap(loaded.Width, loaded.Height);

            for (int x = 0; x < loaded.Width; x++)
            {
                for (int y = 0; y < loaded.Height; y++)
                {
                    pixel = loaded.GetPixel(x, y);
                    processed.SetPixel(x, y, pixel);
                }
            }
            pictureBox2.Image = processed;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (isRunning == true)
            {
                selectedFilter = ApplyGrayscaleFilter;
            }
            else
            {
                loaded = new Bitmap(openFileDialog1.FileName);
                Color pixel;
                int gray;
                processed = new Bitmap(loaded.Width, loaded.Height);

                for (int x = 0; x < loaded.Width; x++)
                {
                    for (int y = 0; y < loaded.Height; y++)
                    {
                        pixel = loaded.GetPixel(x, y);
                        gray = (byte)((pixel.R + pixel.G + pixel.B) / 3);
                        processed.SetPixel(x, y, Color.FromArgb(gray, gray, gray));
                    }
                }
            }
            pictureBox2.Image = processed;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (isRunning == true)
            {
                selectedFilter = ApplyInvertFilter;
            }
            else
            {
                loaded = new Bitmap(openFileDialog1.FileName);
                Color pixel;
                int gray;
                processed = new Bitmap(loaded.Width, loaded.Height);

                for (int x = 0; x < loaded.Width; x++)
                {
                    for (int y = 0; y < loaded.Height; y++)
                    {
                        pixel = loaded.GetPixel(x, y);
                        processed.SetPixel(x, y, Color.FromArgb(255 - pixel.R, 255 - pixel.G, 255 - pixel.B));
                    }
                }
            }
            pictureBox2.Image = processed;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (isRunning == true)
            {
                selectedFilter = ApplySepiaFilter;
            }
            else
            {
                loaded = new Bitmap(openFileDialog1.FileName);
                Color pixel;
                int sepiaIntensity;
                processed = new Bitmap(loaded.Width, loaded.Height);

                for (int x = 0; x < loaded.Width; x++)
                {
                    for (int y = 0; y < loaded.Height; y++)
                    {
                        pixel = loaded.GetPixel(x, y);

                        int sepiaR = (int)(0.393 * pixel.R + 0.769 * pixel.G + 0.189 * pixel.B);
                        int sepiaG = (int)(0.349 * pixel.R + 0.686 * pixel.G + 0.168 * pixel.B);
                        int sepiaB = (int)(0.272 * pixel.R + 0.534 * pixel.G + 0.131 * pixel.B);

                        sepiaR = Math.Max(0, Math.Min(255, sepiaR));
                        sepiaG = Math.Max(0, Math.Min(255, sepiaG));
                        sepiaB = Math.Max(0, Math.Min(255, sepiaB));

                        processed.SetPixel(x, y, Color.FromArgb(sepiaR, sepiaG, sepiaB));
                    }
                }
            }
            pictureBox2.Image = processed;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (isRunning == true)
            {
                selectedFilter = ApplyHistoFilter;
            }
            else
            {
                loaded = new Bitmap(openFileDialog1.FileName);
                Color pixel;
                processed = new Bitmap(loaded.Width, loaded.Height);
                int[] histogram = new int[256];

                for (int x = 0; x < loaded.Width; x++)
                {
                    for (int y = 0; y < loaded.Height; y++)
                    {
                        pixel = loaded.GetPixel(x, y);
                        int intensity = (int)(0.299 * pixel.R + 0.587 * pixel.G + 0.114 * pixel.B);
                        histogram[intensity]++;
                    }
                }

                using (Graphics g = Graphics.FromImage(processed))
                {
                    int maxFrequency = histogram.Max();

                    for (int i = 0; i < histogram.Length; i++)
                    {
                        int barHeight = (int)((double)histogram[i] / maxFrequency * loaded.Height);
                        g.DrawLine(Pens.Black, i, loaded.Height, i, loaded.Height - barHeight);
                    }
                }
            }
            pictureBox2.Image = processed;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (pictureBox2.Image != null)
            {
                using (SaveFileDialog saveFileDialog = new SaveFileDialog())
                {
                    saveFileDialog.Filter = "JPEG Image|*.jpg|PNG Image|*.png|Bitmap Image|*.bmp|GIF Image|*.gif";

                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        string filePath = saveFileDialog.FileName;
                        pictureBox2.Image.Save(filePath);
                        MessageBox.Show("Image saved successfully!");
                    }
                }
            }
            else
            {
                MessageBox.Show("No image to save. Load or process an image first.");
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image Files|*.bmp;*.jpg;*.jpeg;*.png;*.gif|All Files|*.*";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                imageB = new Bitmap(openFileDialog1.FileName);
                pictureBox1.Image = imageB;
                // The openFileDialog1_FileOk event will be triggered when the user selects a file.
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image Files|*.bmp;*.jpg;*.jpeg;*.png;*.gif|All Files|*.*";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                imageA = new Bitmap(openFileDialog1.FileName);
                pictureBox2.Image = imageA;
                // The openFileDialog1_FileOk event will be triggered when the user selects a file.
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (isRunning == true)
            {

            }
            else
            {
                int maxWidth = Math.Max(imageB.Width, imageA.Width);
                int maxHeight = Math.Max(imageB.Width, imageA.Width);

                Bitmap resizedLoadImage = ResizeImage(imageB, maxWidth, maxHeight);
                Bitmap resizedBackgroundImage = ResizeImage(imageA, maxWidth, maxHeight);

                processed = new Bitmap(maxWidth, maxHeight);

                for (int x = 0; x < maxWidth; x++)
                {
                    for (int y = 0; y < maxHeight; y++)
                    {
                        Color pixelA = resizedLoadImage.GetPixel(x, y);
                        Color pixelB = resizedBackgroundImage.GetPixel(x, y);

                        int greenThreshold = 100;
                        if (pixelA.G > greenThreshold && pixelA.G > pixelA.R && pixelA.G > pixelA.B)
                        {
                            processed.SetPixel(x, y, pixelB);
                        }
                        else
                        {
                            processed.SetPixel(x, y, pixelA);
                        }
                    }
                }
            }
            pictureBox3.Image = processed;
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
        }

        private Bitmap ResizeImage(Image image, int width, int height)
        {
            Bitmap resizedImage = new Bitmap(width, height);
            using (Graphics g = Graphics.FromImage(resizedImage))
            {
                g.DrawImage(image, 0, 0, width, height);
            }
            return resizedImage;
        }

        private void StartWebcam()
        {
            try
            {
                if (videoSource == null)
                {
                    videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);

                    if (videoDevices.Count > 0)
                    {
                        videoSource = new VideoCaptureDevice(videoDevices[0].MonikerString);
                        videoSource.NewFrame += VideoSource_NewFrame;


                        videoSource.Start();
                        isRunning = true;
                    }
                    else
                    {
                        MessageBox.Show("No video devices found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error starting webcam: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void VideoSource_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {

            pictureBox1.BeginInvoke((MethodInvoker)delegate
            {
                pictureBox1.Image = (Bitmap)eventArgs.Frame.Clone();
            });

            if (selectedFilter != null)
            {
                pictureBox2.Invoke((MethodInvoker)delegate
                {
                    pictureBox2.Image = selectedFilter((Bitmap)eventArgs.Frame.Clone());
                });
            }
            else
            {
                pictureBox2.Invoke((MethodInvoker)delegate
                {
                    pictureBox2.Image = (Bitmap)eventArgs.Frame.Clone();
                });
            }
        }

        private void Cam_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            if (selectedFilter != null)
            {
                Bitmap webcamFrame = new Bitmap(eventArgs.Frame);
                pictureBox1.Image = selectedFilter(webcamFrame);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            StopWebcam();
        }

        private void StopWebcam()
        {
            videoSource.SignalToStop();
            videoSource.WaitForStop();
            videoSource.NewFrame -= VideoSource_NewFrame;
            videoSource = null;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            StartWebcam();
            isRunning = true;
        }

        private Bitmap ApplyGrayscaleFilter(Bitmap loaded)
        {
            //loaded = new Bitmap(openFileDialog1.FileName);
            Color pixel;
            int gray;
            processed = new Bitmap(loaded.Width, loaded.Height);

            for (int x = 0; x < loaded.Width; x++)
            {
                for (int y = 0; y < loaded.Height; y++)
                {
                    pixel = loaded.GetPixel(x, y);
                    gray = (byte)((pixel.R + pixel.G + pixel.B) / 3);
                    processed.SetPixel(x, y, Color.FromArgb(gray, gray, gray));
                }
            }
            

            return processed;
        }

        private Bitmap ApplyInvertFilter(Bitmap loaded)
        {
            //loaded = new Bitmap(openFileDialog1.FileName);
            Color pixel;
            int gray;
            processed = new Bitmap(loaded.Width, loaded.Height);

            for (int x = 0; x < loaded.Width; x++)
            {
                for (int y = 0; y < loaded.Height; y++)
                {
                    pixel = loaded.GetPixel(x, y);
                    processed.SetPixel(x, y, Color.FromArgb(255 - pixel.R, 255 - pixel.G, 255 - pixel.B));
                }
            }
            return processed;
        }

        private Bitmap ApplySepiaFilter(Bitmap loaded)
        {
            //loaded = new Bitmap(openFileDialog1.FileName);
            Color pixel;
            int sepiaIntensity;
            processed = new Bitmap(loaded.Width, loaded.Height);

            for (int x = 0; x < loaded.Width; x++)
            {
                for (int y = 0; y < loaded.Height; y++)
                {
                    pixel = loaded.GetPixel(x, y);

                    int sepiaR = (int)(0.393 * pixel.R + 0.769 * pixel.G + 0.189 * pixel.B);
                    int sepiaG = (int)(0.349 * pixel.R + 0.686 * pixel.G + 0.168 * pixel.B);
                    int sepiaB = (int)(0.272 * pixel.R + 0.534 * pixel.G + 0.131 * pixel.B);

                    sepiaR = Math.Max(0, Math.Min(255, sepiaR));
                    sepiaG = Math.Max(0, Math.Min(255, sepiaG));
                    sepiaB = Math.Max(0, Math.Min(255, sepiaB));

                    processed.SetPixel(x, y, Color.FromArgb(sepiaR, sepiaG, sepiaB));
                }
            }
            return processed;
        }

        private Bitmap ApplyHistoFilter(Bitmap loaded)
        {
            //loaded = new Bitmap(openFileDialog1.FileName);
            Color pixel;
            processed = new Bitmap(loaded.Width, loaded.Height);
            int[] histogram = new int[256];

            for (int x = 0; x < loaded.Width; x++)
            {
                for (int y = 0; y < loaded.Height; y++)
                {
                    pixel = loaded.GetPixel(x, y);
                    int intensity = (int)(0.299 * pixel.R + 0.587 * pixel.G + 0.114 * pixel.B);
                    histogram[intensity]++;
                }
            }

            using (Graphics g = Graphics.FromImage(processed))
            {
                int maxFrequency = histogram.Max();

                for (int i = 0; i < histogram.Length; i++)
                {
                    int barHeight = (int)((double)histogram[i] / maxFrequency * loaded.Height);
                    g.DrawLine(Pens.Black, i, loaded.Height, i, loaded.Height - barHeight);
                }
            }
            return processed;
        }
    }
}